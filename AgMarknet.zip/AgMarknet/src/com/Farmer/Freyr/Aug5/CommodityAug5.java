package com.Farmer.Freyr.Aug5;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class CommodityAug5
{
	
public WebDriver driver;
	
	@BeforeClass
	public void setup()  
	{	
		System.setProperty("webdriver.chrome.driver", "D:\\GovtWorkSpace\\AgMarknet\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://agmarknet.gov.in/PriceAndArrivals/DatewiseCommodityReport.aspx");
		
	}
	
	
	public void commodityTest(String year, String state, int month) throws InterruptedException, Exception
	{
		
		
		 ArrayList<String> list2 = new ArrayList<>();  
         
	        list2.add("Groundnut pods (raw)");  
	         
	  	
			for(int i=0; i<list2.size();i++) {
				
			
		Thread.sleep(3000);	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,300)");
		
		waitForElementToVisible("cphBody_cboYear");
		new Select(driver.findElement(By.id("cphBody_cboYear"))).selectByVisibleText(year);
		
		Thread.sleep(2000);
		waitForElementToInVisible("cphBody_imgWait");
		waitForElementToVisible("cphBody_cboMonth");
		new Select(driver.findElement(By.id("cphBody_cboMonth"))).selectByIndex(month);
		
		waitForElementToInVisible("cphBody_imgWait");
		waitForElementToVisible("cphBody_cboState");
		new Select(driver.findElement(By.id("cphBody_cboState"))).selectByVisibleText(state);
		
		waitForElementToInVisible("cphBody_imgWait");
		waitForElementToVisible("cphBody_cboCommodity");
		new Select(driver.findElement(By.id("cphBody_cboCommodity"))).selectByVisibleText(list2.get(i));
		waitForElementToInVisible("cphBody_imgWait");
		waitForElementToVisible("cphBody_btnSubmit");
		driver.findElement(By.id("cphBody_btnSubmit")).click();
		
		js.executeScript("window.scrollBy(0,300)");
		
		List<WebElement> a =new ArrayList<WebElement>();
		a=driver.findElements(By.xpath("//th[contains(text(),'Market')]"));	
		if(a.size()>0)
		{
		//click on export to excel
		driver.findElement(By.xpath("//input[@id='cphBody_Button1']")).click();
		
		
	    Thread.sleep(3000);
		//click on back button
		driver.findElement(By.xpath("//a[@id='cphBody_btnBack']")).click();	
		}
		else
		{
		//click on back button
		driver.findElement(By.xpath("//a[@id='cphBody_btnBack']")).click();
		    
		}
				
		}
		
	}
	
	
	public void stateTest(String year, int month) throws InterruptedException, Exception {
		
		  
        ArrayList<String> list1 = new ArrayList<>();  
         
        list1.add("Andhra Pradesh");  
        
        
  	
		for(int i=0; i<list1.size();i++) {
			commodityTest(year, list1.get(i), month);
		}
		
	}
	
	
	public void monthTest(String year) throws InterruptedException, Exception {
		for(int i=1; i<13; i++) {	
			stateTest(year, i);
		}
		
	}
	

	public void waitForElementToVisible(String locator) {
		new WebDriverWait(driver, 100).until(ExpectedConditions.visibilityOfElementLocated(By.id(locator)));
		
	}
	
	public void waitForElementToInVisible(String locator) {
		new WebDriverWait(driver, 100).until(ExpectedConditions.invisibilityOfElementLocated(By.id(locator)));
	}
	
	 
	
	//@Test(priority=1)
	public void getDataYear2019() throws InterruptedException
	{
		try
		{
		monthTest("2019");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=2)
	public void getDataYear2018() throws InterruptedException
	{
		try
		{
		monthTest("2018");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=3)
	public void getDataYear2017() throws InterruptedException 
	{
		try
		{
		monthTest("2017");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=4)
	public void getDataYear2016() throws InterruptedException 
	{
		try
		{
		monthTest("2016");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=5)
	public void getDataYear2015() throws InterruptedException 
	{
		try
		{
		monthTest("2015");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=6)
	public void getDataYear2014() throws InterruptedException
	{
		try
		{
		monthTest("2014");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=7)
	public void getDataYear2013() throws InterruptedException
	{
		try
		{
		monthTest("2013");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=8)
	public void getDataYear2012() throws InterruptedException 
	{
		try
		{
		monthTest("2012");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=9)
	public void getDataYear2011() throws InterruptedException
	{
		try
		{
		monthTest("2011");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=10)
	public void getDataYear2010() throws InterruptedException 
	{
		try
		{
		monthTest("2010");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}

	//@Test(priority=11)
	public void getDataYear2009() throws InterruptedException 
	{
		try
		{
		monthTest("2009");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=12)
	public void getDataYear2008() throws InterruptedException 
	{
		try
		{
		monthTest("2008");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=13)
	public void getDataYear2007() throws InterruptedException 
	{
		try
		{
		monthTest("2007");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=14)
	public void getDataYear2006() throws InterruptedException 
	{
		try
		{
		monthTest("2006");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=15)
	public void getDataYear2005() throws InterruptedException 
	{
		try
		{
		monthTest("2005");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=16)
	public void getDataYear2004() throws InterruptedException 
	{
		try
		{
		monthTest("2004");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=17)
	public void getDataYear2003() throws InterruptedException 
	{
		try
		{
		monthTest("2003");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=18)
	public void getDataYear2002() throws InterruptedException 
	{
		try
		{
		monthTest("2002");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=19)
	public void getDataYear2001() throws InterruptedException 
	{
		try
		{
		monthTest("2001");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	//@Test(priority=20)
	public void getDataYear2000() throws InterruptedException 
	{
		try
		{
		monthTest("2000");
		}
		catch(Throwable t)
		{
		System.out.println(t.getLocalizedMessage());
		Error e1 = new Error(t.getMessage()); 
		e1.setStackTrace(t.getStackTrace()); 
		throw e1;
		}
	}
	
	@AfterClass
	public void teardown()  
	{	
		driver.quit();
		
	}
}
